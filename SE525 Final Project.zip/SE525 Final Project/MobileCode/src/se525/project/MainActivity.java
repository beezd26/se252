package se525.project;

import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.os.AsyncTask;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.ChannelSftp;

import jscheme.JScheme;
import jscheme.SchemeProcedure;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import java.util.Arrays;
import java.io.*;
import java.security.SignedObject;




public class MainActivity extends Activity {

	Boolean polling = false;	

	TextView status_text;
	LinearLayout layout;
	TextView source_label;
	TextView status_label;
	TextView recipient_label;
	TextView init_data_label;
	EditText source_text;
	EditText init_data;
	Button transmit_button;
	Button polling_button;
	Button clear_button;
	ScrollView log_scroll;
	Spinner recipient;

	RetrieveTasks rt;
	TransmitTask tt;

	String uid;
	String password;
	String server_url;
	String remote_path;
	String remote_home;
	String local_storage_inbound;
	String local_storage_outbound;
	String local_storage_pubkeys;
	String local_storage_privkey_path;
	String local_storage_server_privkey_path;
	String local_storage_whitelists;
	String machine_name;
	String recipient_dir;
	String local_storage_temp;
	Peer[] items;
	
	static {
		java.security.Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
	}



	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// UI and environment initialization methods
		// CHECK initializePeerDict AND initializeTransferParams METHOD COMMENTS
		// FOR INSTRUCTIONS ON HOW TO SET UP CLIENT FOR YOUR SCENARIO
		initializePeerDict();
		initializeUI();
		initializeTransferParams();

	
		transmit_button.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
			
				File target = new File(local_storage_outbound + "/" + source_text.getText());

				if(!target.exists() || source_text.getText().toString() == "") {
					updateLog("Input Scheme file not found - transmission failed");
				
				} else if (((Peer) recipient.getSelectedItem()).getValue() == null) {
					updateLog("Recipient not selected - transmission failed");
				
				} else {
			
					tt = new TransmitTask();
			
					tt.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new String[] {source_text.getText().toString(),
							init_data.getText().toString(), ((Peer) recipient.getSelectedItem()).getValue(), 
							((Peer) recipient.getSelectedItem()).toString()});
			
				}
			
			}
		});
	

	
		polling_button.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
			
							
				if (polling) {

					polling = false;				
					rt.cancel(false);
					//polling_button.setText("Start Polling Server");
				
				
				} else {
				
					rt = new RetrieveTasks();
					polling = true;
					rt.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
					polling_button.setText("Stop Polling Server");
				
				}
			
			}
		});
	
	
		clear_button.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
			
				status_text.setText(null);
			
			}
		
		});
	
	
	
	}





	// MainActivity UI initialization method.  Invoked in Activity.onCreate
	private void initializeUI() {
		
		layout = new LinearLayout(this);
		source_label = new TextView(this);
		status_label = new TextView(this);
		init_data_label = new TextView(this);
		recipient_label = new TextView(this);
		status_text = new TextView(this);
		source_text = new EditText(this);
		init_data = new EditText(this);
		transmit_button = new Button(this);
		polling_button = new Button(this);
		clear_button = new Button(this);
		log_scroll = new ScrollView(this);
		
		layout.setOrientation(LinearLayout.VERTICAL);
		source_label.setText("Name of Scheme File to Transmit:");
		init_data_label.setText("Provide argument to transmit with file (optional):");

		transmit_button.setText("Transmit File");
		polling_button.setText("Start Polling Server");
		
		status_label.setText("Event Log:");
		
		clear_button.setText("Clear Log");
		log_scroll.addView(status_text);
		log_scroll.setFillViewport(true);
		
		recipient_label.setText("Select Recipient:");
		recipient = new Spinner(this);
        ArrayAdapter<Peer> adapter = 
                new ArrayAdapter<Peer>( 
                    this,
                    android.R.layout.simple_spinner_item,
                    items );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        recipient.setAdapter(adapter);
		
		layout.addView(recipient_label);
		layout.addView(recipient);
		layout.addView(source_label);
		layout.addView(source_text);
		layout.addView(init_data_label);
		layout.addView(init_data);
		layout.addView(transmit_button);
		layout.addView(polling_button);
		layout.addView(clear_button);
		layout.addView(status_label);
		layout.addView(log_scroll);
		setContentView(layout);

		
	}

	// Setting environment variables for MainActivity.  You should edit these assignments to 
	// match your scenario
	private void initializeTransferParams() {
		
		uid = "sshgroupuser";  //SSH server login id
		//password = "user";  //SSH server login password
		server_url = "192.168.1.110"; //SSH server ip address
		remote_path = "/home/sshgroupuser"; //path of SSH server folder containin unique user directories
		remote_home = "/home/sshgroupuser/davidmobile"; //path of this client's SSH server code retrieval directory
		local_storage_inbound = "/storage/sdcard/inbound";  //path of local folder to which retrieved files are to be downloaded
		local_storage_outbound = "/storage/sdcard/outbound"; //path of local folder where .scm command files to be transmitted are stored
		local_storage_pubkeys = "/storage/sdcard/pubkeys"; //path of local folder where you store public keys
		local_storage_privkey_path = "/storage/sdcard/privkey/daviddesktop.pem"; //path of your private key file
		local_storage_server_privkey_path = "/storage/sdcard/privkey/ssh_rsa"; //path of private key used to log into exchange server
		local_storage_whitelists = "/storage/sdcard/whitelists"; //path of local folder where you store policy whitelists; name of whitelist files must match machine name for which you are setting policy + ".txt"
		local_storage_temp = "/storage/sdcard/temp"; //path of local temp directory where WIP files can be staged
		machine_name = "davidmobile"; //name of your machine
		recipient_dir = "";
		
	}
	
	private void initializePeerDict() {
		
		items = new Peer[9];
		
		//initalizes universe of machines.  Edit the peer object constructors to change the population
		//arg 1 is machine name, arg 2 is related ssh server folder name.
		
		items[0] = new Peer(null, null);
		items[1] = new Peer("blairdesktop", "blairdesktop");
		items[2] = new Peer("blairmobile", "blairmobile");
		items[3] = new Peer("daviddesktop", "daviddesktop");
		items[4] = new Peer("davidmobile", "davidmobile");
		items[5] = new Peer("michaldesktop", "michaldesktop");
		items[6] = new Peer("michalmobile", "michalmobile");
		items[7] = new Peer("markdesktop", "markdesktop");
		items[8] = new Peer("markmobile", "markmobile");
		
	}
	
	
	// GUI log updater
	private void updateLog(String s) {
		
		SimpleDateFormat date_format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		status_text.append(date_format.format(new Date()) + ": " + s + "\n");
		log_scroll.fullScroll(ScrollView.FOCUS_DOWN);
	}
	
	
	

	private void unpackAndExecute(String filename) {

		try {
			updateLog("Unpacking task: " + filename);
			
			FileInputStream fileIn = new FileInputStream(local_storage_inbound + "/" + filename); 
			ObjectInputStream in = new ObjectInputStream(fileIn);
			SignedObject so = (SignedObject) in.readObject();
			in.close();
			fileIn.close();
			
			CodeObject co = CryptoHelper.DeserializeObject(so);
	
			
			// ExecuteScheme es = new ExecuteScheme();
			// es.execute(co.scheme, co.initialData.getBytes(), filename.getBytes());
		
			executeScheme(co.scheme, co.initialData, filename);
			
			File f = new File(local_storage_inbound + "/" + filename);
			f.delete();
		
		
		} catch (Exception e) {
			updateLog("Task " + filename + " execution error: " + e);
		}
		
		
	}
	


	private void executeScheme(byte[] scheme, String initial_data, String command_name) {
	
		try {
		
			updateLog("Executing task: " + command_name);
			final JScheme js = new JScheme(local_storage_whitelists + "/" + (command_name.split("_"))[1] + ".txt");
			ByteArrayInputStream byte_array = new ByteArrayInputStream(scheme);
			BufferedReader reader = new BufferedReader(new InputStreamReader(byte_array));
			js.load(reader);
			js.call("main", initial_data, this);
			updateLog("Task completed: " + command_name);
		
		} catch (Exception e) {
		
			updateLog("Scheme execution error: " + command_name + " " + e.toString());
		}
	}

	

	
	
	private class TransmitTask extends AsyncTask<Object, Void, String> {
	
	
		protected void onPreExecute() {
		

		
			updateLog("Transmission Started...");
		
		}
	
		protected String doInBackground(Object...string_object) {

			try {
				
				 String[] string = Arrays.copyOf(string_object, string_object.length, String[].class);
			
				String output_name = string[0] + "_" + machine_name;
			
				CryptoHelper.CreateSignedObject(local_storage_temp + "/" + output_name, local_storage_outbound + "/" 
						+ string[0], string[1], local_storage_privkey_path);
			
			
				JSch jsch = new JSch();
				JSch.setConfig("StrictHostKeyChecking", "no");
				jsch.addIdentity(local_storage_server_privkey_path);
				Session session = jsch.getSession(uid, server_url, 22);
				//session.setPassword(password.getBytes());
				session.connect();
			
				ChannelSftp channel = (ChannelSftp) session.openChannel("sftp");
				channel.connect();
				
				//channel.cd(remote_path);
				
				channel.put(local_storage_temp + "/" + output_name, channel.pwd() + "/" + string[2]);
			
				channel.disconnect();
				session.disconnect();
			
				File f = new File(local_storage_temp + "/" + output_name);
				f.delete();

				return ("File: " + string[0] +" posted for user " + string [3] + " successfully");
				
			} catch (Exception e) {
			
				return "Transmission Error: " + e.toString();
			
			}

		}
	
		protected void onPostExecute(String result) {
		
			updateLog(result);
		
		}
	
	}





	private class RetrieveTasks extends AsyncTask<Void, String, String> {
	

		
		protected void onPreExecute() {
		
			if (polling) {

				updateLog("Polling Started");
	        
			
			}
		
		}
	
		protected String doInBackground(Void...vd) {

			
			try {
				JSch jsch = new JSch();
				JSch.setConfig("StrictHostKeyChecking", "no");
				jsch.addIdentity(local_storage_server_privkey_path);
				Session session = jsch.getSession(uid, server_url, 22);
				//session.setPassword(password.getBytes());
				session.connect();
		
				ChannelSftp channel = (ChannelSftp) session.openChannel("sftp");
				channel.connect();

				while (true) {
			
					if (this.isCancelled()) {
				
						channel.disconnect();
						session.disconnect();
				
						break;

				
					} else {
				
				
						Vector<ChannelSftp.LsEntry> v = channel.ls(channel.pwd() + "/" + machine_name + "/*");
						

						if(!v.isEmpty()) {
							for(int i =0; i < v.size(); i++) {
								channel.get(channel.pwd() + "/" + machine_name + "/" + v.get(i).getFilename(), local_storage_inbound);
								this.publishProgress(v.get(i).getFilename());
							}
							//channel.cd(remote_home);
							channel.rm(channel.pwd() + "/" + machine_name + "/*");
						}
				
					}
			
			
				} 
		
				return "Cancel Acknowledged";
	
			} catch (Exception e) {

				return "Error: " + e.toString();
			}
		
		}
	
	
		
		protected void onProgressUpdate(String...message) {
			super.onProgressUpdate(message);
		
			try {
				updateLog("Task " + message[0] + " retrieved");
        
				String delim = "[_]+";
				String tokens[] = message[0].split(delim);
			
				FileInputStream fileIn = new FileInputStream(local_storage_inbound + "/" + message[0]);
				ObjectInputStream in = new ObjectInputStream(fileIn);
				SignedObject sigObject = (SignedObject) in.readObject();
				in.close();
				fileIn.close();
			
				if (CryptoHelper.VerifySignedObject(local_storage_pubkeys + "/" + tokens[1] + ".pem", sigObject)) {
				     updateLog("Task " + message[0] + " signature verified");
				     unpackAndExecute(message[0]);
				
				} else {
					updateLog("Task " + message[0] + ":  unable to verify signature - deleting file");
					File f = new File(local_storage_inbound + "/" + message[0]);
					f.delete();
				}
			
        
			

        
			} catch (Exception e) {
			
				updateLog("File Exec Error: " + e.toString());
			}
        
        
        
		}
	
	
		protected void onCancelled(String result) {
		
			polling = false;
			polling_button.setText("Start Polling Server");
			updateLog(result);
			updateLog("Polling Stopped");
		}
	
		protected void onPostExecute(String result) {
		
			polling = false;
			polling_button.setText("Start Polling Server");
			updateLog(result);
			updateLog("Polling Stopped");
		
		}
	
	
	}


	
	


	/*

	public class ExecuteScheme extends AsyncTask<byte[], Void, String> {
	
		protected String doInBackground(byte[]...bytes) {
		
			try {
			
				JScheme js = new JScheme();
				SchemeProcedure proc = (SchemeProcedure) js.eval(new String(bytes[0]));
				js.call(proc);
			
				return "Scheme Execution succeeded: " + new String(bytes[2]);
		
			
			} catch (Exception e) {
			
				return e.toString();
			}
		}
	
		protected void onPostExecute(String result) {
		
			updateLog(result);
		
		}
	
	
	}
	
	 */

	private class Peer {
	
		String spinner_text;
		String value;
	
		public Peer (String id, String dir) {

			this.spinner_text = id;
			this.value = dir;
		}
	
		public String getSpinnerText() {
		
			return this.spinner_text;
		}
	
	
		public String getValue() {
		
			return this.value;
		}
	
		public String toString() {
		
			return this.spinner_text;
		}
	
	}

	
	
}
	



