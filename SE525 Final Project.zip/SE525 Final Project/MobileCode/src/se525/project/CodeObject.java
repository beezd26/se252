package se525.project;

import java.io.File;

@SuppressWarnings("serial")
public class CodeObject implements java.io.Serializable
{
	public String initialData;
	public byte[] scheme;
}
