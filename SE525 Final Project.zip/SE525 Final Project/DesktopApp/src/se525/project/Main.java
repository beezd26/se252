package se525.project;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SignatureException;
import java.security.SignedObject;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Vector;

import jscheme.JScheme;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

public class Main {
	
	//private static String publicKeyLoc = "C:\\Users\\michalk\\Documents\\public_key";
	

	private static String localOutDirectory = "progsToSend";
	private static String localInDirectory = "progsToRun";
	private static String remotePath = "/home/sshgroupuser/";
	private static String machineName = "daviddesktop";
	private static String publicKeyLoc = "keys/";
	private static String[] peers = new String[]{"michaldesktop","michalmobile",
												"daviddesktop","davidmobile",
												"markdesktop","markmobile",
												"blairdesktop","blairmobile"};

	public static void main(String[] args) throws IOException, InterruptedException {
		java.security.Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		while(true){
			
			System.out.println("Press 1 to send a program and 2 to check for programs");	
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

			int selection = 0;

			try {
				String r = br.readLine();
				selection = Integer.parseInt(r);
			} catch (Exception ex) {
				System.out.println("Please enter a correct selection");
			}

			if(selection == 1)
			{
				System.out.println("Enter path to program file to send");
				String fileName = null;
				String receivingMachineName = null;
				String initialData = null;
				try {
					fileName = br.readLine();
					System.out.println("Select the machine to connect to");
					for(int i =0; i<peers.length;i++){
						System.out.println(" (" + (i+1) + ") " + peers[i]);
					}
					String receivingMachine = br.readLine();
					int machineSelection = Integer.parseInt(receivingMachine);
					receivingMachineName = peers[machineSelection-1];
					System.out.println("Enter initial data");
					initialData = br.readLine();
					Sender sender = new Sender(localOutDirectory, machineName, remotePath);
					sender.sendFiles(fileName, receivingMachineName, initialData);

				} catch (Exception ex) {
					System.out.println("Please enter correct data");
				}			

			}
			else if(selection == 2)
			{
				System.out.println("Checking for programs...");
				if(pickupFile()){//if found any files run scheme program.
					try {
						runSchemeProgram();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			else
			{
				System.out.println("Please enter a correct selection");
			}
			
		}
	}
	
	public static boolean pickupFile(){
		boolean copiedFile = false;
		PublicKeyTarget target = new PublicKeyTarget();//target server
		try {
			final JSch jsch = new JSch ();
			JSch.setConfig ("StrictHostKeyChecking", "no");
			System.out.println ("Creating session");
			final Session session = target.getSession (jsch);//getting connection to target server
			session.connect ();//opening connection
			
			System.out.println ("Creating SFTP channel");
			//opening sftp channel to targer server
			final ChannelSftp channel = (ChannelSftp) session.openChannel ("sftp");
			channel.connect ();
			
			Vector files = channel.ls(remotePath + "/" + machineName);
			ArrayList<String> filesFound = new ArrayList<String>();
			for (Object f : files) {
				if (f instanceof com.jcraft.jsch.ChannelSftp.LsEntry) {
					String filename = ((com.jcraft.jsch.ChannelSftp.LsEntry) f).getFilename();
					if(!filename.equals(".") && !filename.equals("..")){
						filesFound.add(filename);
					}
				}
				System.out.println(f.toString());
			}
			
			//creating a input stream to write the file
			//ByteArrayInputStream bais = new ByteArrayInputStream (fileContent.getBytes ("us-ascii"));
			int mode = ChannelSftp.OVERWRITE;
			
			if(filesFound.size() > 0){
				//get files
				for(int i1 = 0; i1 < filesFound.size(); i1++){
					channel.get(remotePath + "/" + machineName + "/" + filesFound.get(i1), localInDirectory);
					channel.rm(remotePath + "/" + machineName + "/" + filesFound.get(i1));//remove copied files
					copiedFile = true;
				}
			}
			
			//channel.put (bais, fileName, mode);//writing the file on alice's directory
			
			//cleanup and close
			channel.disconnect ();
			session.disconnect ();
		} catch (Exception e) {
			System.err.println (e.toString ());
			return false;
		}
		return copiedFile;
	}
	

	public static void runSchemeProgram() throws Exception{
		File folder = new File(localInDirectory);
		File[] listOfFiles = folder.listFiles();
		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile()) {
				System.out.println("File " + listOfFiles[i].getName());
				FileInputStream fileIn = new FileInputStream(localInDirectory + "/" + listOfFiles[i].getName());
				ObjectInputStream in = new ObjectInputStream(fileIn);
				SignedObject so = (SignedObject) in.readObject();
				in.close();
				fileIn.close();
				
				String[] fileParts = listOfFiles[i].getName().split("_");
				String senderName = fileParts[fileParts.length-1];
				
				if(!CryptoHelper.VerifySignedObject(publicKeyLoc + senderName + ".pub", so)){
					File f = new File(localInDirectory + "\\" + listOfFiles[i].getName());
					f.delete();
					continue;
				}
				
				CodeObject co = CryptoHelper.DeserializeObject(so);
				
				
				JScheme scheme = new  JScheme("whitelists/" + senderName + ".txt");
				
				ByteArrayInputStream bArray = new ByteArrayInputStream(co.scheme);				
				BufferedReader reader = new BufferedReader(new java.io.InputStreamReader(bArray));			
				scheme.load(reader);
				
				
				Sender sender = new Sender(localOutDirectory, machineName, remotePath);
				
				scheme.call("main", co.initialData, sender);

				File f = new File(localInDirectory + "\\" + listOfFiles[i].getName());
				f.delete();
			} 
	    }
	}
}


class PublicKeyTarget  {
	String hostname = "192.168.1.110";//host server//192.168.56.101
	String username = "sshgroupuser";//username to use//password group1se525
	int port = 22;//port to connect on
	String privateKeyFileName = "keys/ssh_rsa";//C:\\ssh_private_key
			
	Session getSession (JSch jsch) throws JSchException {//function for getting connection to the remote server
		
		System.out.format ("connecting to %s@%s:%d%n", username, hostname, port);//logging

		jsch.addIdentity (privateKeyFileName);
		Session session = jsch.getSession (username, hostname, port);//getting a connection to the server
		return session;
	}	
}
