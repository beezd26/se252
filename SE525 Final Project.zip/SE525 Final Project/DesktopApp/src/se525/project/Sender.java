package se525.project;

import java.io.File;
import java.io.IOException;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

public class Sender {
	
	private String localOutDirectory;
	private String machineName;
	private String remotePath;
	
	public Sender(String localOutDir, String machineNm, String rmPath){
		localOutDirectory = localOutDir;
		machineName = machineNm;
		remotePath = rmPath;
	}
	
	public boolean sendFiles(String fileName, String receivingMachineName, String initialData) throws IOException{
		File folder = new File(localOutDirectory);
		File[] listOfFiles = folder.listFiles();
		
		String[] parts = fileName.split("/");
		String program = parts[parts.length - 1];
		String[] programParts = program.split("\\.");
	
		String serializedObjectName = program + "_" + machineName;

		try {
			CryptoHelper.CreateSignedObject(localOutDirectory + "/" + serializedObjectName, localOutDirectory + "/" + fileName, initialData, "keys/" + machineName + ".pem");
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		
		PublicKeyTarget target = new PublicKeyTarget();
		final JSch jsch = new JSch ();
		JSch.setConfig ("StrictHostKeyChecking", "no");
		System.out.println ("Creating session");
		Session session;
		try {
			session = target.getSession (jsch);
			//getting connection to target server
			session.connect ();//opening connection
			
			System.out.println ("Creating SFTP channel");
			//opening sftp channel to targer server
			final ChannelSftp channel = (ChannelSftp) session.openChannel ("sftp");
			channel.connect ();
			
			channel.put(localOutDirectory + "/" + serializedObjectName, remotePath + "/" + receivingMachineName);
			
			File f = new File(localOutDirectory + "/" + serializedObjectName);
			f.delete();
			
			//cleanup and close
			channel.disconnect ();
			session.disconnect ();
		} catch (JSchException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;//couldn't connect
		} catch (SftpException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}
}